"use strict";

const DEFAULT_PORT = 17890;

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "yunget-send-link",
    title: "发送到云取 PC 解析/下载",
    contexts: ["link", "page"]
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "yunget-send-link") return;
  const targetUrl = info.linkUrl || info.pageUrl || tab?.url || "";
  if (!targetUrl) return;
  const { relayPort = DEFAULT_PORT } = await chrome.storage.local.get("relayPort");
  try {
    await fetch(`http://127.0.0.1:${relayPort}/enqueue`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: targetUrl,
        mode: "resolve",
        source: "extension"
      })
    });
  } catch {
    // 桌面端未运行时静默忽略，用户可点开弹窗复制链接
  }
});
